

package irrgarten;

/**
 * @brief   Representa a los dos tipos de personajes en el juego
 * @author  Isabel Morro Tabares
 */
public enum GameCharacter { PLAYER, MONSTER; }
