
package irrgarten;

/**
 * @brief   Representa los dos tipos de desplazamientos existentes en el juego
 * @author  Isabel Morro Tabares
 */
public enum Orientation {VERTICAL, HORIZONTAL;}
