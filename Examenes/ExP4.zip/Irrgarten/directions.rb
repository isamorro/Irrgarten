#encoding:utf-8

=begin

    Autor: Isabel Morro Tabares 

    Representa las direcciones en que se puede mover el juagdor
    por el laberinto

=end

module Irrgarten
    module Directions
       LEFT     =:left 
       RIGHT    =:right 
       UP       =:up 
       DOWN     =:down 
    end
end


