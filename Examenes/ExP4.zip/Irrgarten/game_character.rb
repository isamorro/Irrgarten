#encoding:utf-8

=begin

    Autor: Isabel Morro Tabares 

    Representa los dos tipos de personajes del juego

=end

module Irrgarten
    module GameCharacter
        PLAYER  =:player 
        MONSTER =:monster 
    end
end  

#puts Irrgarten::GameCharacter::PLAYER