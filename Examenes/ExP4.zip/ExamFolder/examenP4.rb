
require_relative '../Irrgarten/labyrinth'
require_relative '../Irrgarten/fuzzy_player'
require_relative '../Irrgarten/player'
require_relative '../Irrgarten/dice'
require_relative '../Irrgarten/orientation'
require_relative '../Irrgarten/directions'

module Prueba
	
    class Examen
        def self.main ()
            
            # Creamos el laberinto
            
            labyrinth = Irrgarten::Labyrinth.new(3, 3, 0, 0)
            
            # Creamos jugador
            
            player = Irrgarten::Player.new('1', Irrgarten::Dice.random_intelligence(), Irrgarten::Dice.random_strength())
            player.set_pos(2,2)
            
            # Ponemos al jugador en el laberinto
            labyrinth.put_player_2D(-1, -1, 2, 2, player)
            
            # Visualizamos el laberinto
            
            puts "LABERINTO"
            puts labyrinth.to_s
            
            # Cambiamos el jugador a FuzzyPlayer
            
            playerFuzzy = Irrgarten::FuzzyPlayer.new(player)
            labyrinth.resurrection_fuzzy_player(2, 2, playerFuzzy)
            
            # Visualizamos el laberinto
            
            puts "LABERINTO"
            puts labyrinth.to_s
            
            # Creamos instancia de FUzzyPlayerGoneNuts
            
            fp = FuzzyPlayerGoneNuts.new('2', Irrgarten::Dice.random_intelligence(), Irrgarten::Dice.random_strength())
            fp.set_pos(4,4)
            
            # Método asociado al movimiento
            
            valid_moves = labyrinth.valid_moves(fp.row, fp.col)
            for i in (0..9)
            	puts fp.move(Irrgarten::Directions::UP, valid_moves)
            end
            
            # Vemos el jugador
            puts fp.inspect
            
        end
    end
    
    
    class FuzzyPlayerGoneNuts < Irrgarten::Player
    
    	def initialize(number, intelligence, strength)
    		super
    		@contador_movimiento_fuzzy = 0
    		@contador_movimiento_arriba = 0
    	end
    
    	def move (direction, valid_moves)
    		result = super
    		if (Irrgarten::Dice.comport_fuzzy)
    			@contador_movimiento_fuzzy += 1
    			return Irrgarten::Dice.next_step(result, valid_moves, @intelligence)
    		else 
    			@contador_movimiento_arriba += 1
    			return Irrgarten::Directions::UP
    		end
    	end
    	
    end
    
end

Prueba::Examen.main
