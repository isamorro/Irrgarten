/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package main;

import irrgarten.Controller.Controller;
import irrgarten.Game;
import irrgarten.UI.GUI;
import irrgarten.UI.UI;

/**
 *
 * @author luciacepeda
 */
public class PlayWithGUI {
     public static void main (String []args){
        
        int njugadores = 2;
        UI vista = new GUI();
        Game game = new Game(njugadores);
        Controller controller = new Controller (game, vista);
        controller.play();
    
    }
}
    

