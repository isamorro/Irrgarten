/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package irrgarten;

/**
 *
 * @author luciacepeda
 */
public abstract class LabyrinthCharacter {
    
    // Atributos de instancia
    private String name;
    private float intelligence;
    private float strength;
    private float health;
    private int row;
    private int col;
    
    //Constructor
    public LabyrinthCharacter(String name, float intelligence, float strength, 
                                float health){
        this.name = name;
        this.intelligence = intelligence;
        this.strength = strength;
        this.health = health;
        row = -1;
        col = -1; 
        
    }
    
    //Constructor de copia
    public LabyrinthCharacter(LabyrinthCharacter other){
        this(other.name, other.intelligence,other.strength, other.health);
        setPos(other.getRow(),other.getCol());
    }
    
    // Consultores
    public int getRow(){
        return row;
    }
    
    public int getCol(){
        return col;
    }    
    
    // Modificadores
    public void setPos (int row, int col){
       this.row = row;
       this.col = col;
    }
    
    
    // Métodos públicos
    public boolean dead(){
        return health <= 0;
    }
    
    public abstract float attack();
    
    public abstract boolean defend(float attack); 
    
    @Override
    public String toString(){
        String cadena = "";
        cadena += "[" + name + "\n " 
                    +"Intelligence: " + intelligence + "\n " 
                    + "Strength: " + strength + "\n " 
                    + "Health: " + health + "\n "
                    + "Position: (" + row + "," + col + ")]\n";
        return cadena;
    }
    
    // Metodos de paquete
    float getIntelligence(){
        return intelligence;
    }
    
    float getStrength(){
        return strength;
    }
    
    float getHealth(){
        return health;
    }
    
    void setHealth(float health){
        this.health= health;
    }
    
    void gotWounded(){
        if (health > 0)
           health -= 1;
    }
    
}
