
package irrgarten;

/**
 * @brief Esta clase representa las armas que utiliza el jugador en los ataques 
 *      durante los combates.
 * @author luciacepeda
 */
public class Weapon extends CombatElement {
    
        
    public Weapon (float _power, int _uses){
        super(_power, _uses);
    }
   
    public float attack (){
       return produceEffect();      
    }

    @Override
    public String toString (){
        String cadena = "W";
        cadena += super.toString();
        return cadena;
    }
}
