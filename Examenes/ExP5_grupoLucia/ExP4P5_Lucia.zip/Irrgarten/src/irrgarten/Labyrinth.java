/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package irrgarten;

import java.util.ArrayList;

/**
 * @brief Abstracción del tablero laberinto del juego 
 * @author luciacepeda
 */
public class Labyrinth {
    
    // Constantes de clase
    private static final char BLOCK_CHAR = 'X';
    private static final char EMPTY_CHAR = '-';
    private static final char MONSTER_CHAR = 'M';
    private static final char COMBAT_CHAR = 'C';
    private static final char EXIT_CHAR = 'E';
    private static final int ROW = 0;
    private static final int COL = 1;
    
    // Atributos privados
    private int nRows;
    private int nCols;
    private int exitRow;
    private int exitCol;
    
    // Atributos generados por asociación
    private Monster[][] monsters;
    private Player[][] players;
    private char[][] labyrinth;
    
    
    // Constructor
    public Labyrinth(int nRows, int nCols, int exitRow, int exitCol){
        this.nRows= nRows;
        this.nCols = nCols;
        this.exitRow = exitRow;
        this.exitCol = exitCol;  
        
        // Matrices inicializadas a null
        monsters = new Monster[nRows][nCols];
        players = new Player[nRows][nCols];
        // Matriz inicializada con el carácter nulo '\u0000'
        labyrinth = new char[nRows][nCols];  
        
        
        for (int i = 0; i < nRows ; i++){
          for (int j = 0; j < nCols; j++){

              if (i == 0 || i == nRows-1 || j == 0 || j == nCols-1){
                  labyrinth[i][j] = BLOCK_CHAR; 
              }
              else labyrinth[i][j] = EMPTY_CHAR; 

              monsters[i][j] = null;
              players[i][j] = null;
          }
        }
        
        labyrinth [this.exitRow][this.exitCol] = EXIT_CHAR;
    }
    
    
    /***********************************************************************
     * MÉTODOS PÚBLICOS
     **********************************************************************/
    public void spreadPlayers(ArrayList <Player> players){
        /*
        for (Player p : players){
            int[] pos = randomEmptyPos();
            putPlayer2D(-1, -1, pos[ROW], pos[COL], p);
        }    
        */
        putPlayer2D(-1, -1, 2, 4, players.get(0));
        putPlayer2D(-1, -1, 1, 6, players.get(1));


    }
    
    /**
     * @return Devuelve true si hay un jugador en la casilla de salida y false si
     *      no hay ninguno
     */
    public boolean haveAWinner(){
        return players[exitRow][exitCol] != null;
    }
    
    /**
     * @brief Si es posOK and emptyPos -> anota Monster en el laberinto
     *        Indica al Monster su posición y guarda la referencia del Monstruo en 
     *        el contenedor adecuado
     * @param row fila donde posicionar Monstruo
     * @param col columna donde posicionar Monstruo
     * @param monster referencia de la abstracción de un Monster
     */
    public void addMonster(int row, int col, Monster monster){
        if(posOK(row,col)){ 
            if(emptyPos(row,col)){
                labyrinth[row][col] = MONSTER_CHAR;
                monster.setPos(row, col);
                monsters[row][col] = monster;
            }
        }
    }
    
    public void setFuzzyPlayer(int row, int col, FuzzyPlayer fuzzyPlayer){
        players[row][col] = fuzzyPlayer;
    }
    
    public Monster putPlayer(Directions direction, Player player){
        int oldRow = player.getRow();
        int oldCol = player.getCol();
        int[] newPos = dir2Pos(oldRow, oldCol, direction);
        Monster monster = putPlayer2D(oldRow, oldCol, newPos[ROW], newPos[COL], player);
        return monster;   
    }
    
    public void addBlock(Orientation orientation, int startRow, int startCol, int length){
        int incRow, incCol;
        
        if (orientation == Orientation.VERTICAL){
            incRow = 1;
            incCol = 0;
        }
        else {
            incRow = 0;
            incCol = 1;
        }
        
        int row = startRow;
        int col = startCol;
        
        while (posOK(row,col) && emptyPos(row,col) && length > 0){
            labyrinth[row][col] = BLOCK_CHAR;
            length -= 1;
            row += incRow;
            col += incCol;
        }    
    }
    
    public ArrayList <Directions> validMoves(int row, int col){
        
        ArrayList<Directions> output = new ArrayList<>();
        
        if (canStepOn(row+1, col)) output.add(Directions.DOWN);
        if (canStepOn(row-1, col)) output.add(Directions.UP);
        if (canStepOn(row, col+1)) output.add(Directions.RIGHT);
        if (canStepOn(row, col-1)) output.add(Directions.LEFT);
        
        return output;   
    }
    
    @Override
    public String toString(){
        String cadena = "";
        cadena += "Laberinto de dimensiones: " + nRows + "x" + nCols + "\n";
        cadena += "Casilla de salida: (" + exitRow + "," + exitCol + ")\n";
        cadena += "Mostrando laberinto... \n";
        for(int i=0; i< nRows ; i++){
            for (int j=0; j< nCols ; j++){
                cadena+= labyrinth[i][j] + " ";
            }
            cadena+= "\n";
        }
                
        return cadena;
    }
    
    /***********************************************************************
     * MÉTODOS PRIVADOS
     **********************************************************************/
    private boolean posOK(int row, int col){
        return (row < nRows && col < nCols) && (row >= 0 && col>=0);
    }
    
    private boolean emptyPos(int row, int col){
       return (labyrinth[row][col]== EMPTY_CHAR);
    }
    
    private boolean monsterPos(int row, int col){
       return (labyrinth[row][col]== MONSTER_CHAR);
    } 
    
    private boolean exitPos(int row, int col){
       return (labyrinth[row][col]== EXIT_CHAR);
    } 
    
    private boolean combatPos(int row, int col){
       return (labyrinth[row][col]== COMBAT_CHAR);
    } 
    
    private boolean canStepOn(int row, int col){
        return posOK(row,col) && (emptyPos(row,col) || monsterPos(row,col) || exitPos(row,col));
    }
    
    /**
     * @brief Actualiza laberinto cuando un jugador se mueve de la casilla dada
     * @param row fila a actualizar
     * @param col columna a actualizar
     */
    private void updateOldPos(int row, int col){
        if(posOK(row,col)){
            if(combatPos(row,col)) // Si había combate, se queda sólo el monstruo
                labyrinth[row][col] = MONSTER_CHAR;
            else                
                labyrinth[row][col] = EMPTY_CHAR;     
        }       
    }
    
    /**
     * @brief Calcula la posición a la que se llegaría si desde la posición dada se 
     *      avanza en la dirección pasada
     *      (0,0) es la esquina superior izquierda del tablero
     *      NO ASEGURA QUE LA POSICIÓN CALCULADA ESTE DENTRO DEL TABLERO
     * @param row 
     * @param col
     * @param direction 
     * @return posición si se mueve en la dirección dada
     */
    private int[] dir2Pos(int row, int col, Directions direction){
         
        int[] posicion = new int[2];
        switch (direction) {
             case LEFT:
                posicion[ROW] = row;
                posicion[COL] = col - 1;
                break;
            case RIGHT:
                posicion[ROW] = row;
                posicion[COL] = col + 1;
                break;
            case DOWN:
                posicion[ROW] = row + 1;
                posicion[COL] = col;
                break;
            case UP:
                posicion[ROW] = row - 1;
                posicion[COL] = col;
                break;          
        }
        
        return posicion;
    }
    /**
     * @brief genera una posición aleatoria en el laberinto (fila y columna) 
     *      asegurando que esta esté vacía.
     *      Si no hay posiciones vacías se producirá un bucle infinito.
     * @return 
     */
    private int[] randomEmptyPos(){ 
        int row = -1;
        int col = -1;
        
        do{
            row = Dice.randomPos(nRows);
            col = Dice.randomPos(nCols);    
        }while(!emptyPos(row,col));
        
        int[] pos = new int[2];
        pos[ROW]= row;
        pos[COL]= col;
        
        return pos;       
    }
    
    // ESTE MÉTODO ES PRIVADO!!!!
    private Monster putPlayer2D(int oldRow, int oldCol, int row, int col, Player player){
        Monster output = null;
        
        if (canStepOn(row,col)){
            
            if(posOK(oldRow, oldCol)){
                Player p = players[oldRow][oldCol];
                if (p == player){
                    updateOldPos(oldRow, oldCol);
                    players[oldRow][oldCol] = null;
                }
            }
            
            boolean monsterPos = monsterPos(row, col);
            
            if (monsterPos){
                labyrinth[row][col] = COMBAT_CHAR;
                output = monsters[row][col];
            }
            else {
                char number = player.getNumber();
                labyrinth[row][col] = number;
            }
            
            players[row][col] = player;
            player.setPos(row, col); 
        }
        
        return output;    
    }
}
