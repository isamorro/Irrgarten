/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package irrgarten;

/**
 * @brief   Representa a los dos tipos de personajes en el juego
 * @author luciacepeda
 */
public enum GameCharacter { PLAYER, MONSTER}
