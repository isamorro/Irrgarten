/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package irrgarten;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * @brief Abstracción de jugador
 * @author luciacepeda
 */
public class Player extends LabyrinthCharacter  {
    
    // Constantes de clase
    private static final int MAX_WEAPONS = 2;
    private static final int MAX_SHIELDS = 3;
    private static final int INITIAL_HEALTH = 10;
    private static final int HITS2LOSE = 5;
    
    // Atributos de instancia
    private char number;
    private int consecutiveHits;
    
    // Atributos generados por asociación
    private ArrayList<Weapon> weapons;
    private ArrayList<Shield> shields;
    private ShieldCardDeck shieldCardDeck;
    private WeaponCardDeck weaponCardDeck;
    
    
    // Constructor
    public Player(char _number, float _intelligence, float _strength){
        super("Player #" + _number,_intelligence, _strength, INITIAL_HEALTH);
        number = _number;
        consecutiveHits = 0;

        weapons = new ArrayList<>();
        shields = new ArrayList<>(); 
        shieldCardDeck = new ShieldCardDeck();
        weaponCardDeck = new WeaponCardDeck();
        
    }

    public Player(Player other){
        super(other);
        number = other.getNumber();
        consecutiveHits = other.consecutiveHits;
        weapons = other.weapons;
        shields = other.shields; 
    }
    
    public char getNumber(){
        return number;
    }
   
    public void resurrect (){
        weapons.clear();
        shields.clear(); 
        setHealth(INITIAL_HEALTH);
        resetHits();
    }
    
    public Directions move(Directions direction, ArrayList<Directions> validMoves){
        int size = validMoves.size();
        boolean contained = validMoves.contains(direction);
        Directions result;
        
        if (size>0 && !contained)
            result = validMoves.get(0);
        else
            result = direction;
        
        return result;    
    }
    
    @Override
    public float attack (){
        return getStrength() + sumWeapons();
    }
    
    @Override
    public boolean defend(float receivedAttack){
        return manageHit(receivedAttack);
    }
    
    
    public void receiveReward(){
        int wReward = Dice.weaponsReward();
        int sReward = Dice.shieldsReward();
        
        for (int i=0; i < wReward; i++){
            Weapon wnew = newWeapon();
            receiveWeapon(wnew);
        }
        
        for (int i=0; i < sReward; i++){
            Shield snew = newShield();
            receiveShield(snew);
        }
        
        int extraHealth = Dice.healthReward();
        extraHealth += getHealth();
        setHealth(extraHealth);
    }
    
    @Override
    public String toString(){
        String cadena = super.toString();
        cadena+= " ";
        if(!weapons.isEmpty()){
            for(Weapon w: weapons){
                cadena+= w.toString() + "\n ";
            }
        }
        if(!shields.isEmpty()){
            for(Shield s: shields){
                cadena+= s.toString() + "\n ";
            }
        }
        return cadena;
    }
    
    // Métodos de paquete
    float sumWeapons(){
        float sumatoria = 0f;
        for (Weapon w: weapons){
            sumatoria += w.attack();
        }
        return sumatoria;
    }
  
    float sumShields(){
        float sumatoria = 0f;
        for(Shield s: shields){
            sumatoria += s.protect();
        }
        return sumatoria;
    }
    
    float defensiveEnergy(){
        return getIntelligence() + sumShields();
    }
    
    /***************************************************
     * METODOS PRIVADOS
     **************************************************/
    private void receiveWeapon(Weapon w){
        
        Iterator<Weapon> iterator = weapons.iterator();
        while (iterator.hasNext()) {
            Weapon weapon = iterator.next();
            boolean discard = weapon.discard();
            if (discard) {
                iterator.remove(); // Remove the weapon using the iterator
            }
        }

        int size = weapons.size();
        if (size < MAX_WEAPONS) {
            weapons.add(w);
        }
        /*boolean discard;
        
        System.out.print(weapons.size());
        
        for (Weapon wi : weapons){
            if (wi.discard()) weapons.remove(wi);
        }
        
        if (weapons.size() < MAX_WEAPONS) weapons.add(w); 
        */
    }
    
    private void receiveShield(Shield s){
        Iterator<Shield> iterator = shields.iterator();
        while (iterator.hasNext()) {
            Shield shield = iterator.next();
            boolean discard = shield.discard();
            if (discard) {
                iterator.remove(); // Remove the shield using the iterator
            }
        }

        int size = shields.size();
        if (size < MAX_SHIELDS) {
            shields.add(s);
        }
        /*for (Shield si : shields){
            if (si.discard()) shields.remove(si);
        }
       
        if (shields.size() < MAX_SHIELDS) shields.add(s);
        */
    }   
    
      
    private Weapon newWeapon(){
        return weaponCardDeck.nextCard();
    }
    
  
    private Shield newShield(){
        return shieldCardDeck.nextCard();
    }
      
    
    private boolean manageHit(float receivedAttack){
        float defense = defensiveEnergy();
        boolean lose;
        
        if (defense < receivedAttack){
            gotWounded();
            incConsecutiveHits();
        }
        else resetHits();
        
        if ( consecutiveHits == HITS2LOSE || dead()){
            resetHits();
            lose = true;
        }
        else lose = false;
        
        return lose;
    }
    
    /**
     * @brief Fija el contador de impactos consecutivos a cero
     */
    private void resetHits(){
        consecutiveHits = 0;
    }
    
    /**
     * @brief Incrementa en una unidad el contador de impactos consecutivos.
     */
    private void incConsecutiveHits(){
        consecutiveHits++;
    }
    
  
    
}
