
package irrgarten.UI;

import irrgarten.Directions;
import irrgarten.GameState;

/**
 *
 * @author luciacepeda
 */
public interface UI {
    public Directions nextMove();
    public void showGame(GameState gameState);
    public default boolean massiveConversion(){
        return false;
    }


}
