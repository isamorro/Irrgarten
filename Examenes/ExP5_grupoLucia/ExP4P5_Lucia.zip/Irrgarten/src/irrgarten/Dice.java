/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package irrgarten;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author luciacepeda
 * 
 * Toma las decisiones que dependen del azar en el juego.
 * No tiene sentido que existan distintas instancias de esta clase en distintos 
 * estados.
 */
public class Dice {
    
    private static final int MAX_USES = 5; // max usos de armas y escudos
    private static final float MAX_INTELLIGENCE = 10.0f; // Valor max para la inteligencia de jugadores
    private static final float MAX_STRENGTH = 10.0f; // Valor max para la fuerza de jugadores
    private static final float RESURRECT_PROB = 0.3f; // Prob de que un jugador sea resucitado en cada turno
    private static final int WEAPONS_REWARD = 2; // Num max de armas recibidas al ganar combate
    private static final int SHIELDS_REWARD = 3; // Num max de escudos recibidos al ganar un combate
    private static final int HEALTH_REWARD = 5; // Num max de uds de salud recibidas al ganar un combate
    private static final int MAX_ATTACK = 3; // Max potencia de las armas
    private static final int MAX_SHIELD = 2; // Max potencia de los escudos
    private static final float PROB = 0.5f; // Prob de que un jugador sea resucitado en cada turno

    
    private static Random generator = new Random();
        
    // Métodos
    
    /**
     * @brief Devuelve num fila o columna del tablero aleatoria
     * @param max numero de filas/columnas del tablero cuadrado
     * @return valor entre [0,max[
     */
    public static int randomPos (int max){
        return generator.nextInt(max);
    }
 
    public static boolean mitadProb(){
        return generator.nextFloat() < PROB;
    }
    /**
     * @return Devuelve valor entre [0,MAX_INTELLIGENCE[
     */
    public static float randomIntelligence(){
        float n = generator.nextFloat() * MAX_INTELLIGENCE;
        return n;
    }
    
    /**
     * @return Devuelve valor entre [0,MAX_STRENGTH[
     */
    public static float randomStrength(){
        return generator.nextFloat() * MAX_STRENGTH;
    }
    
    
    /**
     * @brief Devuelve el índice del jugador que comienza la partida
     * @param nplayers max num de jugadores en la partida
     * @return valor entre [0,nplayers[
     */
    public static int whoStarts(int nplayers){
        return generator.nextInt(nplayers);
    }
    
 
    /**
     * @brief Indica si un jugador muerto debe ser resucitado o no con dicha probabilidad
     * @return  true si se resucita o false en caso contrario
     */
    public static boolean resurrectPlayer(){
        return (generator.nextFloat() < RESURRECT_PROB);
    }
    
    /**
     *  @brief Devuelve el numero de armas que recibe un jugador por ganar un combate
     *  @return valor entre [0,WEAPONS_REWARD]
     */
    public static int weaponsReward(){
        return generator.nextInt(WEAPONS_REWARD +1); // +1 para que sea inclusive
    }
    
    /**
     *  @brief  Devuelve el numero de escudos que recibe un jugador por ganar un combate
     *  @return valor entre [0,SHIELDS_REWARD]
     */
    public static int shieldsReward(){
        return generator.nextInt(SHIELDS_REWARD +1);
    }
    
    /**
     *  @brief  Devuelve la cantidad de uds de salud recibe un jugador por ganar un combate.
     *  @return valor entre [0,HEALTH_REWARD]
     */
    public static int healthReward(){
        return generator.nextInt(HEALTH_REWARD +1);
    }
    
    /**
     *  @return  Devuelve un valor aleatorio en el intervalo [0, MAX_ATTACK[
     */
    public static float weaponPower(){
        return generator.nextInt(MAX_ATTACK);
    }
    
    /**
     *  @return Devuelve un valor aleatorio en el intervalo [0, MAX_SHIELD[
     */
    public static float shieldPower(){
        return generator.nextInt(MAX_SHIELD);
    }
    
    /**
     *  @return  Devuelve un valor aleatorio en el intervalo [0, MAX_USES]
     */
    public static int usesLeft(){
        return generator.nextInt(MAX_USES +1);
    }
    
   
    /**
     * @brief Devuelve la cantidad de competencia
     * @param competence max cantidad de competencia
     * @return valor aleatorio en el intervalo [0,competence[
     */
    public static float intensity(float competence){
       return generator.nextFloat() * competence;
    }
    
    
    /**
     * @brief   Devuelve true con una probabilidad inversamente proporcional a 
     *          lo cercano que esté el parámetro del número máximo de usos que 
     *          puede tener un arma o escudo
     * @param   usesLeft
     * @return  true si usesLeft es 0 y false si el número máximo de usos
     */
    public static boolean discardElement(int usesLeft){
        return generator.nextInt(MAX_USES) >= usesLeft;  
        /*  float discardProbability = (float) (MAX_USES - usesLeft) / MAX_USES;
        return generator.nextFloat() < discardProbability;*/
    }

    /**
     * @brief Devuelve mov preferente con una prob del valor de intelligence.
     *      Sino, elige dirección al azar de validMoves
     * @param preference
     * @param validMoves
     * @param intelligence
     * @return 
     */
    public static Directions nextStep(Directions preference, ArrayList<Directions> validMoves, 
                                        float intelligence){
        if(generator.nextFloat() < (intelligence*0.1))
            return preference;
        else {
            int i = generator.nextInt(validMoves.size());
            return validMoves.get(i);
        }
    }
    
}
