/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package irrgarten;

/**
 * @brief   Enumerado que representa las direcciones en que se puede mover el 
 *          jugador por el laberinto
 * @author luciacepeda
 */
public enum Directions {LEFT, RIGHT, UP, DOWN}
