/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package irrgarten;

import java.util.ArrayList;

/**
 * @brief Un FuzzyPlayer solo puede crearse a partir de otro jugador y 
 *      dicha creación se produce como resultado de la resurrección del mismo.
 * @author luciacepeda
 */
public class FuzzyPlayer extends Player{
    
    public FuzzyPlayer(Player other){
        super(other);
    }
    
    @Override
    public Directions move(Directions direction, ArrayList<Directions> validMoves){    
        Directions direccionMove = super.move(direction, validMoves);
        return Dice.nextStep(direccionMove, validMoves, getIntelligence());
    }
    
    @Override
    public float attack(){
        return sumWeapons() + Dice.intensity(getStrength());
    }

    @Override
    float defensiveEnergy(){
        return sumShields() + Dice.intensity(getIntelligence());
    }
    
    @Override
    public String toString(){
        String cadena = "Fuzzy";
        cadena += super.toString();
        return cadena;
    }
}
