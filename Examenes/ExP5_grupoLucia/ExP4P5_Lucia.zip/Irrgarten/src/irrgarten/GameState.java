/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package irrgarten;

/**
 * @brief Almacena representación del estado completo del juego
 * 
 * @author luciacepeda
 */
public class GameState {
    
    // Atributos privados
    private String labyrinth; // estado del laberinto
    private String players; // estado
    private String monsters; // estado
    private int currentPlayer; // índice
    private boolean winner; // indica si hay ganador
    private String log; // eventos turno anterior
    private boolean allFuzzy;
    
    
    // Constructor
    public GameState (String _labyrinth, String _players, String _monsters,
                      int _currentPlayer, boolean _winner, String _log, boolean af){
        
        labyrinth = _labyrinth;
        players = _players;
        monsters = _monsters;
        currentPlayer = _currentPlayer;
        winner = _winner;
        log = _log;
        allFuzzy = af;
    }   
    
    /***********************************************************************
    * CONSULTORES PÚBLICOS
    **********************************************************************/
    
    public String getLabyrinthv (){
        return this.labyrinth;
    }
    
    public String getPlayers (){
        return this.players;
    }
    
    public String getMonsters (){
        return this.monsters;
    }
    
    public int getCurrentPlayer (){
        return this.currentPlayer;
    }
    
    public boolean isWinner (){
        return this.winner;
    }
    
    public String getLog (){
        return this.log;
    } 
    
    public boolean isAllFuzzy(){
        return allFuzzy;
    }
    
    @Override
    public String toString(){
        String cadena = "";
       
        cadena += labyrinth + "\n";
        cadena += players + "\n";
        cadena += monsters + "\n";
        cadena += log + "\n";
        
        /*
        cadena += "TURNO: JUGADOR " + currentPlayer + "\n";
        
        if (winner) cadena += "HAY GANADOR!!!!" + "\n" + "FELICIDADES JUGADOR " 
                    + currentPlayer + "\n";
        */      
        return cadena;
   }
}
