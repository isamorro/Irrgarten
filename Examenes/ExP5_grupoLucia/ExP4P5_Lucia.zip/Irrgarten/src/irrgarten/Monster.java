/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package irrgarten;

/**
 * @brief Abstracción de mosntruo
 * @author luciacepeda
 */
public class Monster extends LabyrinthCharacter {
    
    private static final int INITIAL_HEALTH = 15;
    
    // Constructor
    public Monster(String _name, float _intelligence, float _strength){
        super(_name, _intelligence, _strength,INITIAL_HEALTH);       
    }
  
    @Override
    public float attack (){
        return Dice.intensity(getStrength());
    }
    
    @Override
    public boolean defend(float receivedAttack){
        boolean isDead = dead();
        if (!isDead){
            float defensiveEnergy = Dice.intensity(getIntelligence());
            if (defensiveEnergy < receivedAttack){
                gotWounded();
                isDead = dead();
            }
        }
        return isDead;    
    }
    
    
    
    
}
