
package irrgarten;

/**
 * @brief Esta clase representa los escudos que utiliza el jugador cuando se 
 *      defiende de un ataque de un monstruo.
 * @author luciacepeda
 */
public class Shield extends CombatElement{
    
    
    public Shield (float _protection, int _uses){
        super(_protection, _uses);
    }
    
 
    public float protect (){
       return produceEffect();      
    }
    
    @Override
    public String toString (){
        String cadena = "S";
        cadena += super.toString();
        return cadena;
    }

    
}
