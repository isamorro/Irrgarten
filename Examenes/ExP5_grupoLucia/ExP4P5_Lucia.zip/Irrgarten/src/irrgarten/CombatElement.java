
package irrgarten;

/**
 *
 * @author luciacepeda
 */
public abstract class CombatElement {
    
    private float effect;
    private int uses;
    
    public CombatElement(float _effect, int _uses){
        effect= _effect;
        uses = _uses;
    }
    
    
    public boolean discard(){
        return Dice.discardElement(uses);
    }
    
    float produceEffect(){
        if(uses > 0){
            uses--;
            return effect;
        }
        else return 0.0f;
    }
    
    @Override
    public String toString (){
        String cadena = "[" + effect + ", " + uses + "]";
        return cadena;
    }
    
}
