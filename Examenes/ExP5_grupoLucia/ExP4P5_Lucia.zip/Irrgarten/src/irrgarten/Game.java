/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package irrgarten;

import java.util.ArrayList;

/**
 *
 * @author luciacepeda
 */
public class Game {
    
    // Constantes de clase
    private static final int MAX_ROUNDS = 10;
    
    // Atributos privados
    private int currentPlayerIndex;
    private String log;
    
    // Atributos generados por asociacion
    private ArrayList<Player> players;
    private Player currentPlayer;
    private ArrayList<Monster> monsters;
    private Labyrinth labyrinth;
    
    private boolean allFuzzy;
    
    // Constructor
    
    public Game(int nPlayers){
        
        log = "";
        
        // Creación de jugadores
        players = new ArrayList<>();
        for (int i=0; i < nPlayers; i++){
            players.add(new Player((char)('0'+ i),
                    Dice.randomIntelligence(),Dice.randomStrength()));// Character.forDigit(i, nPlayers)
        }

        // Determinar quien empieza
        currentPlayerIndex = Dice.whoStarts(nPlayers);
        currentPlayer = players.get(currentPlayerIndex);
        logNewTurn();
        
        monsters =  new ArrayList<>();
        labyrinth = new Labyrinth(10, 10, 0, 1); // Valores a escoger
        
        // Configura el laberinto y reparte jugadores
        configureLabyrinth();
        labyrinth.spreadPlayers(players);
        allFuzzy = false;

    }
    public boolean getAllFuzzy(){
        return allFuzzy;
    }
    
    public void setAllFuzzy(boolean b){
        allFuzzy = b;
    }
    /***********************************************************************
    * MÉTODOS PÚBLICOS
    **********************************************************************/
    /**
     * @brief Delega en el método del laberinto que indica si hay un ganador.
     * @return true si hay ganador, false en caso contrario
     */
    public boolean finished(){
        return labyrinth.haveAWinner();
    }
    
    public boolean nextStep(Directions preferredDirection){
        log = "";
        boolean dead = currentPlayer.dead();
        
        if (!dead){
            
            Directions direction = actualDirection(preferredDirection);
            
            if (direction != preferredDirection)
                logPlayerNoOrders();
            
            Monster monster = labyrinth.putPlayer(direction, currentPlayer);
            
            if (monster == null) logNoMonster();
            else {
                GameCharacter winner = combat(monster);
                manageReward(winner);
            }
        }
        else 
            manageResurrection();
        
        boolean endGame = finished();
        
        // Yo he añadido logEndOfGame()
        if (!endGame)
            nextPlayer();
        else
            logEndOfGame();
        
        return endGame;    
    }
    
    /**
     * @brief Genera una instancia de GameState integrando toda la información del 
     *      estado del juego
     * @return referencia a GameState actual
     */
    public GameState getGameState(){
        
        String estadoPlayers = "";
        for(Player p: players){
            estadoPlayers+= p.toString() + "\n";

        }
        
        String estadoMonstruos = "";
        for(Monster m: monsters){
            estadoMonstruos+= m.toString()+ "\n";
        }
        
        boolean hayGanador = finished();
        
        GameState estadoJuego = new GameState(labyrinth.toString(),estadoPlayers,
                                        estadoMonstruos, currentPlayerIndex, hayGanador, log, getAllFuzzy());
        
        return estadoJuego;
    }
    
    /***********************************************************************
    * MÉTODOS PRIVADOS
    **********************************************************************/
    /**
     * @brief Configura el laberinto añadiendo bloques de obstáculos y monstruos
     *      Es totalmente nuestra elección de laberinto.
     */
    private void configureLabyrinth(){
        
        //labyrinth.addBlock(Orientation.HORIZONTAL, 2, 3, 1);
        
        Monster m1 = new Monster ("Monstruo #" + 1,10.0f,10.0f);
       // Monster m2 = new Monster ("Monstruo #" + 2,10.0f,10.0f);
        //Monster m3 = new Monster ("Monstruo #" + 3,10.0f,10.0f);

        /*
        Monster m2 = new Monster ("Monstruo #" + 2, Dice.randomIntelligence(),
                                             Dice.randomStrength());
        Monster m3 = new Monster ("Monstruo #" + 3, Dice.randomIntelligence(),
                                             Dice.randomStrength());
        */
        
        labyrinth.addMonster(1, 4, m1);
      //  labyrinth.addMonster(3, 7, m2);
      //  labyrinth.addMonster(1, 4, m3);
        
        monsters.add(m1);
       // monsters.add(m2);
       // monsters.add(m3);
        
        
    }
    
    /**
     * @brief actualiza los atributos current del jugador al pasar de turno
     */
    private void nextPlayer(){
        
        int anterior = currentPlayerIndex;        
        do{
            currentPlayerIndex = Dice.whoStarts(players.size());
        } while (currentPlayerIndex == anterior);
        
        currentPlayer = players.get(currentPlayerIndex);  
        logNewTurn();
    }
    
    private Directions actualDirection(Directions preferredDirection){
        int currentRow = currentPlayer.getRow();
        int currentCol = currentPlayer.getCol();
        ArrayList<Directions> validMoves = labyrinth.validMoves(currentRow, currentCol);
        Directions output = currentPlayer.move(preferredDirection, validMoves);
        return output;    
    }
    
    private GameCharacter combat(Monster monster){
        int rounds = 0;
        
        GameCharacter winner = GameCharacter.PLAYER;
        
        float playerAttack = currentPlayer.attack();
        boolean lose = monster.defend(playerAttack);
        
        while ((!lose) && (rounds < MAX_ROUNDS)){
            
            winner = GameCharacter.MONSTER;
            rounds++;

            float monsterAttack = monster.attack();
            lose = currentPlayer.defend(monsterAttack);
            
            if (!lose){
                playerAttack = currentPlayer.attack();
                winner = GameCharacter.PLAYER;
                lose = monster.defend(playerAttack);
            }
            
        }
        
        logRounds(rounds, MAX_ROUNDS);
        return winner;
    }
    
    private void manageReward(GameCharacter winner){
        if (winner == GameCharacter.PLAYER){
            currentPlayer.receiveReward();
            logPlayerWon();
        }
        else {
            logMonsterWon();
        }
         
    }
    
    
    private void manageResurrection(){
        boolean resurrect =true; 
                //Dice.resurrectPlayer();
     
        if (resurrect){
            currentPlayer.resurrect();
            makeFuzzyPlayer();
            logResurrected();
        }
        else 
            logPlayerSkipTurn();    
    }
    
    private void makeFuzzyPlayer(){
        FuzzyPlayer fp = new FuzzyPlayer(currentPlayer);
        currentPlayer =fp;
        players.set(currentPlayerIndex, currentPlayer);
        labyrinth.setFuzzyPlayer(currentPlayer.getRow(), currentPlayer.getCol(), fp);
    }
    
    public void makeAllFuzzyPlayer(){
        if(!getAllFuzzy()){
            int i=0;
            for(Player p: players){
                FuzzyPlayer fp = new FuzzyPlayer(p);
                p =fp;
                players.set(i, p);
                labyrinth.setFuzzyPlayer(p.getRow(), p.getCol(), fp);
                i++;
            }
        }
        setAllFuzzy(true);
        
    }
    
    private void logPlayerWon(){
        log += " El JUGADOR #" + currentPlayerIndex + " HA GANADO EL COMBATE\n";
    }
    
    private void logMonsterWon(){
        log += " El MONSTRUO HA GANADO EL COMBATE\n";
    }
    
    private void logResurrected(){
        log += " El JUGADOR #" + currentPlayerIndex + " HA RESUCITADO. AHORA ES UN FUZZY PLAYER\n";        
    }
    
    private void logPlayerSkipTurn(){
        log += " El JUGADOR #" + currentPlayerIndex + " ESTA MUERTO, HA PERDIDO EL TURNO\n";
    }
    
    private void logPlayerNoOrders(){
        log += " El JUGADOR #" + currentPlayerIndex + " NO HA SEGUIDO LAS INSTRUCCIONES (NO FUE POSIBLE)\n"; 
    }
    
    private void logNoMonster(){
        log += " El JUGADOR #" + currentPlayerIndex + " SE HA MOVIDO A UNA CELDA "
            + "VACIA O NO HA PODIDO MOVERSE \n";        
    }
    
    private void logRounds(int rounds, int max){
        log += " SE HAN USADO " + rounds + " RONDAS DE " + max + " MAXIMAS\n";        
    }

    private void logNewTurn(){
        log+= " TURNO JUGADOR # " + currentPlayerIndex + "\n";
    }
    
    private void logEndOfGame(){
        log+=  " HAY GANADOR!!!!" + "\n" + " FELICIDADES JUGADOR #" + currentPlayerIndex + "\n";
    }
}