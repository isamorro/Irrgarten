/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package irrgarten;

/**
 *
 * @author luciacepeda
 */
public class WeaponCardDeck extends CardDeck<Weapon> {

    @Override
    void addCards() {
        // Creamos instancias de Weapon para crear mazo de carta predeterminado
        int nCards = 6;
        
        for(int i=0; i<nCards; i++){
            addCard(new Weapon(Dice.weaponPower(),Dice.usesLeft()));
        }
        
    }
    
}
