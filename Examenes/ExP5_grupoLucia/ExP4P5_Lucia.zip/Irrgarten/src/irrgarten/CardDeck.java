
package irrgarten;

import java.util.ArrayList;
import java.util.Collections;


/**
 *
 * @author luciacepeda
 * @param <T>
 */
public abstract class CardDeck<T extends CombatElement> {
        
    //Atributos privados
    private ArrayList<T> cardDeck = new ArrayList<>();
    
    public CardDeck(){}
    
    abstract void addCards();
    
    void addCard(T card){
        cardDeck.add(card);
    }
    
    public T nextCard(){
        if(cardDeck.isEmpty()){
            addCards();
            Collections.shuffle(cardDeck);
        }
        T card = cardDeck.remove(0);
        return card;
    }
    
}
