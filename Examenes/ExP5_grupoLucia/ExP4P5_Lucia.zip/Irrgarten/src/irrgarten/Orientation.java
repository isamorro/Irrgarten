/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package irrgarten;

/**
 * @brief Representa los dos tipos de desplazamientos existentes en el juego
 * @author luciacepeda
 */
public enum Orientation { VERTICAL, HORIZONTAL}
