/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package irrgarten;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author luciacepeda
 */
public class TestP4 {
    public static void main (String[] args){
           
        ArrayList<Directions> direcciones = new ArrayList<>(List.of(
                Directions.DOWN,Directions.LEFT, Directions.RIGHT, Directions.UP));
        
        float inteligenciaAlta = 0.8f;
        float inteligenciaBaja = 0.2f;
        
        for(int i=0; i<10; i++){
            System.out.println(Dice.nextStep(Directions.LEFT, direcciones,inteligenciaAlta ));
        }
        
        System.out.println("************************************************");
        
        for(int i=0; i<10; i++){
            System.out.println(Dice.nextStep(Directions.LEFT, direcciones,inteligenciaBaja ));
        }
        
        System.out.println("************************************************");

        float protection = 0.2f;
        int uses = 5;
        float power = 1.4f;
        Shield s = new Shield(protection, uses);
        Weapon w = new Weapon(power, uses);
        
        System.out.println(w.toString());
        System.out.println(s.toString());
        System.out.println(w.produceEffect());
        System.out.println(w.attack());
        System.out.println(w.discard());
        System.out.println(s.produceEffect());
        System.out.println(s.protect());
        System.out.println(s.discard());
        System.out.println(w.toString());
        System.out.println(s.toString());
        
        // Comprobar que si resucita se convierte en Fuzzy Player
        System.out.println("************************************************");

        
        Labyrinth miLaberinto = new Labyrinth(5,5,0,1);
        System.out.println(miLaberinto.toString());
        
        int nPlayers = 2;
        ArrayList<Player> players = new ArrayList<>();
        for(int i=0; i<nPlayers; i++ ){
            players.add( new Player( Character.forDigit(i, nPlayers),
                                        Dice.randomIntelligence(),
                                        Dice.randomStrength())
                        );
        }
        
        //miLaberinto.putPlayer2D(-1, -1, 2, 2, players.get(0));
        Monster m1 = new Monster ("Monstruo #" + 1, Dice.randomIntelligence(),
                                             Dice.randomStrength());
        miLaberinto.addMonster(1, 2, m1);
        System.out.println(miLaberinto.toString());
        System.out.println(players.get(0).toString());
        System.out.println(m1.toString());
        System.out.println("Fuerza de ataque: " + players.get(0).attack());
        System.out.println("Fuerza defensiva: " + players.get(0).defensiveEnergy());
        
        System.out.println("Player resucita y se convierte en Fuzzy!!!!!!");
        players.get(0).resurrect();
        players.add(0, new FuzzyPlayer(players.get(0)));
        System.out.println(miLaberinto.toString());
        System.out.println(players.get(0).toString());
        System.out.println(m1.toString());
        System.out.println("Fuerza de ataque: " + players.get(0).attack());
        System.out.println("Fuerza defensiva: " + players.get(0).defensiveEnergy());
        ArrayList<Directions> valid_moves = 
            miLaberinto.validMoves(players.get(0).getRow(), players.get(0).getCol());
        for(Directions d:valid_moves){
            System.out.println(d + " ") ;
        }
        Directions direccion_F;
        direccion_F= players.get(0).move(Directions.UP, valid_moves);
        System.out.println("Dirección tomada: " + direccion_F);
       // int pos[]= miLaberinto.dir2Pos(players.get(0).getRow(), players.get(0).getCol(), direccion_F);
      //  miLaberinto.putPlayer2D(players.get(0).getRow(), players.get(0).getCol(),
        //                pos[0],pos[1], players.get(0));
        System.out.println(miLaberinto.toString());
        System.out.println(players.get(0).toString());
        System.out.println(m1.toString());
        
        
        
        
/*
        
        ArrayList<Directions> dir= new ArrayList<>(List.of(Directions.UP,Directions.DOWN));
        Directions next_dir;
        next_dir = players.get(0).move(Directions.UP,dir);
        System.out.println(miLaberinto.toString());
        System.out.println(players.get(0).toString());
        System.out.println(m1.toString());
        
        
        

        Monster monster = miLaberinto.putPlayer(next_dir, players.get(0));
        System.out.println(miLaberinto.toString());
        final int MAX_R= 4;
        boolean lose;
        if (monster != null){
            // Hay combate
            
            float playerAttack = players.get(0).attack();
            lose = monster.defend(playerAttack +1000.0f);
            System.out.println(miLaberinto.toString());
            System.out.println(players.get(0).toString());
            System.out.println(monster.toString());
            int rounds = 0;
            

            while ((!lose) && (rounds < MAX_R)){
            
                rounds++;

                float monsterAttack = monster.attack();
                lose = players.get(0).defend(monsterAttack);

                if (!lose){
                    playerAttack = players.get(0).attack();
                    lose = monster.defend(playerAttack);
                }
            
            }   
        }
        if(players.get(0).dead()){
           // resucitar
           players.get(0).resurrect();
           players.add(0, new FuzzyPlayer(players.get(0)));
           System.out.println("Ha resucitado!!!!!!");
           System.out.println(players.get(0).toString());


        }
         
        next_dir = players.get(0).move(Directions.LEFT,dir);
        System.out.println(miLaberinto.toString());
        System.out.println(players.get(0).toString());
        System.out.println(m1.toString());
       
        */

        System.out.println("************************************************");
        
        
    }
}
