/*
 * Copyright 2023 Lucia 
 * http://marxsoftware.blogspot.com/
 */
package irrgarten;

/**
 *
 * @author luciacepeda
 */
public class ShieldCardDeck extends CardDeck<Shield> {

    @Override
    void addCards() {
        // Creamos instancias de Shield para crear mazo de carta predeterminado
        int nCards = 6;
        
        for(int i=0; i<nCards; i++){
            addCard(new Shield(Dice.shieldPower(),Dice.usesLeft()));
        }
    }
    
}
