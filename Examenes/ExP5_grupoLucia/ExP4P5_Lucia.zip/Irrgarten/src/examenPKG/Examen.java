/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenPKG;

import irrgarten.CombatElement;
import irrgarten.Dice;
import irrgarten.Shield;
import irrgarten.Weapon;
import java.util.ArrayList;

/**
 *
 * @author luciacepeda
 */

class FaultyWeapon extends Weapon{
        
        public FaultyWeapon(float _power, int _uses) {
            super(_power, _uses);
        }
        
        @Override
        public float attack (){
            if(Dice.mitadProb()){
                return 0.0f;
            }
            else{
                return super.attack();
            }
        }
        
        
}
public class Examen {
   
    
    public static void main (String []args){
        ArrayList<CombatElement> combate= new ArrayList<>();
        FaultyWeapon w = new FaultyWeapon(Dice.weaponPower(),Dice.usesLeft());
        combate.add(new Weapon(Dice.weaponPower(),Dice.usesLeft()));
        combate.add(new Shield(Dice.shieldPower(),Dice.usesLeft()));
        combate.add(w);
         
        for(CombatElement c: combate){
            System.out.println(c.discard());
            float attack = w.attack();
        }
        
        

    }
}
