#encoding:utf-8

=begin

    Autor: Isabel Morro Tabares 

    Representa los dos tipos de desplazamientos existentes en el juego

=end


module Irrgarten
    module Orientation
        VERTICAL    =:vertical 
        HORIZONTAL  =:horizontal
    end
end